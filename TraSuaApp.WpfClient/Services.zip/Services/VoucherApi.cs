﻿using TraSuaApp.Shared.Dtos;
using TraSuaApp.Shared.Enums;
using TraSuaApp.Shared.Helpers;
using TraSuaApp.WpfClient.Apis;

namespace TraSuaApp.WpfClient.Services;

public class VoucherApi : BaseApi, IVoucherApi
{
    private const string BASE_URL = "/api/Voucher";

    public VoucherApi() : base(TuDien._tableFriendlyNames["Voucher"]) { }

    public async Task<Result<List<VoucherDto>>> GetAllAsync()
    {
        return await GetAsync<List<VoucherDto>>(BASE_URL);
    }

    public async Task<Result<VoucherDto>> GetByIdAsync(Guid id)
    {
        return await GetAsync<VoucherDto>($"{BASE_URL}/{id}");
    }

    public async Task<Result<VoucherDto>> CreateAsync(VoucherDto dto)
    {
        return await PostAsync<VoucherDto>(BASE_URL, dto);
    }

    public async Task<Result<VoucherDto>> UpdateAsync(Guid id, VoucherDto dto)
    {
        return await PutAsync<VoucherDto>($"{BASE_URL}/{id}", dto);
    }

    public async Task<Result<VoucherDto>> DeleteAsync(Guid id)
    {
        return await DeleteAsync<VoucherDto>($"{BASE_URL}/{id}");
    }

    public async Task<Result<VoucherDto>> RestoreAsync(Guid id)
    {
        return await PutAsync<VoucherDto>($"{BASE_URL}/{id}/restore", null!);
    }

    public async Task<Result<List<VoucherDto>>> GetUpdatedSince(DateTime since)
    {
        return await GetAsync<List<VoucherDto>>($"{BASE_URL}/sync?lastSync={Uri.EscapeDataString(since.ToUniversalTime().ToString("o"))}");
    }


    public Task<Result<List<VoucherChiTraDto>>> GetByOffset(int offset)
         => GetAsync<List<VoucherChiTraDto>>($"{BASE_URL}/by-offset?offset={offset}");

    public Task<Result<List<VoucherChiTraDto>>> GetThisMonth()
        => GetByOffset(0);

    public Task<Result<List<VoucherChiTraDto>>> GetLastMonth()
        => GetByOffset(-1);
}
